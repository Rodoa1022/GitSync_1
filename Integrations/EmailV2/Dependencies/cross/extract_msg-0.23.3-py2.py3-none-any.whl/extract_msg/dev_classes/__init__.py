from extract_msg.dev_classes.attachment import Attachment
from extract_msg.dev_classes.message import Message
