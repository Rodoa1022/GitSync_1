# -*- coding: utf-8 -*-

import logging

"""
extract_msg.exceptions
~~~~~~~~~~~~~~~~~~~
This module contains the set of extract_msg exceptions.
"""

# add logger bus
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class InvalidFileFormat(OSError):
    """
    A Invalid File Format Error occurred.

    """

    def __init__(self, message, filename=None):
        super().__init__(message)
        self.filename = filename

    def __str__(self):
        msg = self.strerror  # Use strerror for the default message

        # If a filename was provided, add it to the message
        if self.filename:
            msg = f"{msg}: '{self.filename}'"

        return msg